import flask
import gunicorn
import jinja2
import markupsafe
import werkzeug
import numpy
import scipy
import sklearn
import pandas 
print(flask.__version__)
print(gunicorn.__version__)
print(jinja2.__version__)
print(markupsafe.__version__)
print(werkzeug.__version__)
print(numpy.__version__)
print(scipy.__version__)
print(sklearn.__version__)
print(pandas.__version__)
